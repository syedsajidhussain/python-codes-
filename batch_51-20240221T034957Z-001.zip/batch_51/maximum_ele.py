

def num_append(num):
  num.append("nadeem")
  return num

def num_insert(num):


def num_del(num):
