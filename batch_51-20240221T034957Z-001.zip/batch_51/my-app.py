from maximum_ele import num_append
list_2= ["Sajid", "Dev", "krish"]
print(num_append(list_2))





