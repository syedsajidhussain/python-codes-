def prof(sp):
  return sp * 0.2